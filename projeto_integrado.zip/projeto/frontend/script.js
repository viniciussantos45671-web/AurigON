// ===== Conexão com a API (back-end) =====
// Servido pelo Express (http://localhost:3000) usa o mesmo endereço; aberto direto do disco (file://) aponta para a porta 3000.
// Para usar outra API, defina window.API_URL antes de carregar este script.
const API=window.API_URL||(location.protocol==='file:'?'http://localhost:3000/api':'/api');
async function api(caminho){const r=await fetch(API+caminho);let j=null;try{j=await r.json()}catch(e){}
if(!r.ok||!j||!j.sucesso)throw new Error((j&&j.erro)||'A API respondeu com erro '+r.status+'.');return j.dados}
const DIAS=['Segunda','Terça','Quarta','Quinta','Sexta'];
let TURMAS=[],PROF=[],SALAS=[],MAT=[],AULAS=[];
const turno=h=>h<'12:00'?'Manhã':h<'18:00'?'Tarde':'Noite';
async function carregar(){
const [turmas,professores,salas,horarios]=await Promise.all([api('/turmas'),api('/professores'),api('/salas'),api('/horarios')]);
AULAS=horarios.map(a=>({t:a.turma,di:a.dia_id-1,h:a.hora_inicio,hf:a.hora_fim,mat:a.disciplina,prof:a.professor||'Sem professor',temProf:!!a.professor,sala:a.sala,grupo:a.grupo}));
TURMAS=turmas.map(t=>{const hs=AULAS.filter(a=>a.t==t.nome).map(a=>a.h).sort();return [t.nome,hs.length?turno(hs[0]):'—']});
PROF=professores.map(p=>p.nome);
SALAS=salas.map(s=>s.nome);
MAT=[...new Set(AULAS.map(a=>a.mat))].sort((a,b)=>a.localeCompare(b,'pt-BR'))}
const unicos=(arr,k)=>[...new Set(arr.map(a=>a[k]))];
const conflitos=()=>{const s=new Set();let n=0;AULAS.forEach(a=>['prof','sala'].forEach(k=>{if(k=='prof'&&!a.temProf)return;const key=k+a.di+a.h+a[k];if(s.has(key))n++;s.add(key)}));return n};
const hojeIdx=(()=>{const g=new Date().getDay();return g>=1&&g<=5?g-1:0})();
const cores=['#4aa3df','#a07be0','#e5b04a','#e56a7d','#7b66d6','#4a8fd6'];
const $=s=>document.querySelector(s);
const ROTAS={painel:['Painel','M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z'],grade:['Grade horária','M3 5h18v16H3zM3 10h18M8 3v4M16 3v4'],turmas:['Turmas','M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8'],professores:['Professores','M2 9l10-5 10 5-10 5zM6 11v5c3 2 9 2 12 0v-5'],materias:['Matérias','M2 4h7a3 3 0 0 1 3 3v14a2 2 0 0 0-2-2H2zM22 4h-7a3 3 0 0 0-3 3v14a2 2 0 0 1 2-2h8z']};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const opts=(arr,all)=>`<option value="">${all}</option>`+arr.map(x=>`<option>${esc(x)}</option>`).join('');
const grp=a=>a.grupo=='Inteira'?'':` · Grupo ${a.grupo}`;
const aulaRow=a=>`<div class="row"><span>${a.h}</span><span class="bar" style="background:${cores[Math.max(0,TURMAS.findIndex(x=>x[0]==a.t))%cores.length]}"></span><div><b>${esc(a.mat)}</b><small>${esc(a.prof)} · ${esc(a.sala)}${grp(a)}</small></div><span class="chip">${esc(a.t)}</span></div>`;
const V={
painel(){const h=new Date().getHours(),sd=h<12?'Bom dia':h<18?'Boa tarde':'Boa noite',c=conflitos();
const hoje=AULAS.filter(a=>a.di==hojeIdx).sort((a,b)=>a.h.localeCompare(b.h));
const dt=new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long'});
const tn=['Manhã','Tarde','Noite'].map(n=>TURMAS.filter(t=>t[1]==n).length+' '+n.toLowerCase()).join(' · ');
const max=Math.max(1,...TURMAS.map(([t])=>AULAS.filter(a=>a.t==t).length));
return `<div class="top"><div><h1>${sd}, Vinicius.</h1><p>${dt}</p></div><a class="btn" href="#grade">Abrir grade horária</a></div>
<div class="stats"><div class="card stat"><span>Turmas ativas</span><b>${TURMAS.length}</b><small>${tn}</small></div>
<div class="card stat"><span>Professores</span><b>${PROF.length}</b><small>corpo docente</small></div>
<div class="card stat"><span>Aulas na semana</span><b>${AULAS.length}</b><small>em ${TURMAS.length} turmas</small></div>
<div class="card stat"><span>Conflitos</span><b>${c}</b><small>${c?'revise a grade':'nenhum choque de horário'}</small></div></div>
<div class="two"><section class="card" aria-labelledby="hj"><h3>Aulas de hoje · ${DIAS[hojeIdx]}</h3><h2 id="hj">${hoje.length} aulas em ${new Set(hoje.map(a=>a.t)).size} turmas</h2>${hoje.slice(0,8).map(aulaRow).join('')}${hoje.length>8?`<p style="color:var(--mut);font-size:.85rem">e mais ${hoje.length-8} aulas hoje · <a href="#grade" style="color:var(--pri)">ver todas</a></p>`:''}</section>
<div style="display:grid;gap:1.25rem;align-content:start"><section class="card"><h3>Atenção</h3><b>${c?c+' choque(s) de professor ou sala na semana.':'Nenhum choque de professor ou sala na semana.'}</b></section>
<section class="card"><h3>Aulas por turma</h3><div class="occ">${TURMAS.map(([t])=>{const n=AULAS.filter(a=>a.t==t).length;return `<div><p><span>${esc(t)}</span><span>${n}</span></p><div><i style="width:${Math.round(n/max*100)}%"></i></div></div>`}).join('')}</div></section></div></div>`},
grade(){return `<div class="top"><div><h1>Grade horária</h1><p>Filtre por turma, professor, dia ou sala.</p></div></div>
<form class="filters" onsubmit="return false"><label>Turma<select id="fT">${opts(TURMAS.map(x=>x[0]),'Todas')}</select></label><label>Professor<select id="fP">${opts(PROF,'Todos')}</select></label><label>Dia<select id="fD">${opts(DIAS,'Todos')}</select></label><label>Sala ou laboratório<select id="fS">${opts(SALAS,'Todas')}</select></label></form>
<p id="cnt" aria-live="polite" style="color:var(--mut)"></p><div class="tw"><table><thead><tr><th>Dia</th><th>Horário</th><th>Turma</th><th>Matéria</th><th>Professor</th><th>Sala</th></tr></thead><tbody id="tb"></tbody></table></div>`},
turmas(){return `<div class="top"><div><h1>Turmas</h1><p>${TURMAS.length} turmas técnicas ativas.</p></div></div><div class="grid">${TURMAS.map(([t,tn])=>{const as=AULAS.filter(a=>a.t==t);return `<div class="card"><h3>${esc(t)}</h3><p>Turno: ${tn}</p><p>${as.length} aulas por semana</p><p>${new Set(as.filter(a=>a.temProf).map(a=>a.prof)).size} professores</p><a class="btn" href="#grade" data-turma="${esc(t)}" style="margin-top:.6rem">Ver horário</a></div>`}).join('')}</div>`},
professores(){return `<div class="top"><div><h1>Professores</h1><p>${PROF.length} docentes.</p></div></div><div class="grid">${PROF.map(p=>{const as=AULAS.filter(a=>a.prof==p);return `<div class="card"><h3>${esc(p)}</h3><p>${esc(unicos(as,'mat').join(', ')||'Sem aulas na grade')}</p><p>${as.length} aulas por semana</p><a class="btn" href="#grade" data-prof="${esc(p)}" style="margin-top:.6rem">Ver horário</a></div>`}).join('')}</div>`},
materias(){return `<div class="top"><div><h1>Matérias</h1><p>${MAT.length} disciplinas.</p></div></div><div class="grid">${MAT.map(m=>{const as=AULAS.filter(a=>a.mat==m);return `<div class="card"><h3>${esc(m)}</h3><p>${esc(unicos(as.filter(a=>a.temProf),'prof').join(', ')||'Sem professor')}</p><p>${as.length} aulas por semana</p></div>`}).join('')}</div>`}};
let pre={};
function filtrar(){const f={t:$('#fT').value,p:$('#fP').value,d:$('#fD').value,s:$('#fS').value};
const r=AULAS.filter(a=>(!f.t||a.t==f.t)&&(!f.p||a.prof==f.p)&&(!f.d||DIAS[a.di]==f.d)&&(!f.s||a.sala==f.s)).sort((a,b)=>a.di-b.di||a.h.localeCompare(b.h)||a.t.localeCompare(b.t,'pt-BR')||a.grupo.localeCompare(b.grupo));
$('#cnt').textContent=r.length+' aula(s) encontrada(s)';
$('#tb').innerHTML=r.length?r.map(a=>`<tr><td>${DIAS[a.di]}</td><td>${a.h}–${a.hf}</td><td><span class="chip">${esc(a.t)}</span></td><td>${esc(a.mat)}</td><td>${esc(a.prof)}</td><td>${esc(a.sala)}${grp(a)}</td></tr>`).join(''):'<tr><td colspan="6" class="empty">Nenhuma aula com esses filtros. Limpe um filtro para ver mais resultados.</td></tr>'}
function rota(){const k=(location.hash.slice(1)||'painel');const r=V[k]?k:'painel';
$('#menu').innerHTML=Object.entries(ROTAS).map(([id,[n,d]])=>`<li><a href="#${id}" ${id==r?'aria-current="page"':''}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="${d}"/></svg>${n}</a></li>`).join('');
$('#main').innerHTML=V[r]();document.title='AurigON · '+ROTAS[r][0];
if(r=='grade'){['#fT','#fP','#fD','#fS'].forEach(s=>$(s).onchange=filtrar);if(pre.t)$('#fT').value=pre.t;if(pre.p)$('#fP').value=pre.p;pre={};filtrar()}}
document.addEventListener('click',e=>{const a=e.target.closest('[data-turma],[data-prof]');if(a)pre={t:a.dataset.turma,p:a.dataset.prof}});
addEventListener('hashchange',()=>{if(!AULAS.length&&!TURMAS.length)return;rota();$('#main').focus();scrollTo(0,0)});
// Carrega os dados da API e só então desenha a tela (com estados de carregamento e de erro).
async function iniciar(){
$('#main').innerHTML='<p role="status" style="color:var(--mut)">Carregando horários…</p>';
try{await carregar();rota()}
catch(e){$('#main').innerHTML=`<div class="card" role="alert"><h2>Não foi possível carregar os horários</h2><p>${esc(e.message)}</p><p style="color:var(--mut)">Confira se o back-end está rodando (<code>npm start</code>) e se o MySQL está ativo.</p><button class="btn fill" id="retry">Tentar novamente</button></div>`;$('#retry').onclick=iniciar}}
// Acessibilidade
const R=document.documentElement;let S={fs:16,contrast:0,font:0,space:0,motion:0,focus:0,theme:''};
try{Object.assign(S,JSON.parse(localStorage.getItem('aurigon-a11y')||'{}'))}catch(e){}
function aplica(){R.style.setProperty('--fs',S.fs+'px');R.dataset.contrast=S.contrast;R.dataset.font=S.font;R.dataset.space=S.space;R.dataset.motion=S.motion;R.dataset.focus=S.focus;if(S.theme)R.dataset.theme=S.theme;else R.removeAttribute('data-theme');
try{localStorage.setItem('aurigon-a11y',JSON.stringify(S))}catch(e){}
$('#panel').innerHTML=`<h2>Acessibilidade</h2><div class="opt"><span>Tamanho do texto</span><span><button data-a="fs-" aria-label="Diminuir texto">A−</button> <button data-a="fs+" aria-label="Aumentar texto">A+</button></span></div>`+
[['theme','Tema escuro'],['contrast','Alto contraste'],['font','Fonte de leitura fácil'],['space','Espaçamento ampliado'],['motion','Reduzir animações'],['focus','Destaque de foco']].map(([k,n])=>`<div class="opt"><span>${n}</span><button data-a="${k}" aria-pressed="${k=='theme'?S.theme=='dark':!!S[k]}">${(k=='theme'?S.theme=='dark':S[k])?'Ligado':'Desligado'}</button></div>`).join('')+`<button class="btn" data-a="reset">Restaurar padrão</button>`}
$('#panel').addEventListener('click',e=>{const k=e.target.closest('[data-a]')?.dataset.a;if(!k)return;
if(k=='fs+')S.fs=Math.min(24,S.fs+2);else if(k=='fs-')S.fs=Math.max(13,S.fs-2);else if(k=='reset')S={fs:16,contrast:0,font:0,space:0,motion:0,focus:0,theme:''};else if(k=='theme')S.theme=S.theme=='dark'?'light':'dark';else S[k]=S[k]?0:1;aplica()});
$('#a11yBtn').onclick=e=>{const o=$('#panel').classList.toggle('open');e.currentTarget.setAttribute('aria-expanded',o)};
addEventListener('keydown',e=>{if(e.key=='Escape'&&$('#panel').classList.contains('open')){$('#panel').classList.remove('open');$('#a11yBtn').setAttribute('aria-expanded',false);$('#a11yBtn').focus()}});
aplica();iniciar();
